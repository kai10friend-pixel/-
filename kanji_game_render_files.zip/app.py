# -*- coding: utf-8 -*-
"""
漢字タップシューティングゲーム - Gradio版

Google Colabで使う場合:
1. pip install gradio
2. このファイルを実行
3. 表示された公開URLを開く
"""

import html
import os
import gradio as gr

# 元のゲームのHTML・CSS・JavaScript
html_content = r"""

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>漢字タップシューティング</title>
    <style>
        body {
            font-family: sans-serif;
            text-align: center;
            background-color: black; /* 背景を黒に */
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #ffffff; /* 全体の文字色を白に */
        }
        canvas {
            background-color: rgba(0, 0, 0, 0.7); /* キャンバスの背景は透明度のある黒を維持 */
            border: 2px solid #333;
            margin-top: 10px;
        }
        #game-info {
            margin-top: 10px;
            font-size: 20px;
            color: #ffffff; /* スコアと残り時間の文字色を白に */
            min-height: 25px;
            display: flex;
            justify-content: space-around;
            width: 100%;
            max-width: 600px;
        }
        #hiragana-display {
            font-size: 48px; /* お題の熟語の読みを大きく */
            font-weight: bold;
            color: cyan; /* お題の熟語の読みをシアンに */
            margin: 15px 0 5px 0;
            min-height: 40px;
            text-align: center;
            width: 100%;
            max-width: 600px;
        }
        h1 {
            color: gold; /* タイトルを金色に */
        }
        #start-button, #restart-button {
            padding: 10px 20px;
            font-size: 20px;
            margin-top: 20px;
            cursor: pointer;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        #start-button:hover, #restart-button:hover {
            background-color: #45a049;
        }
        #start-button:disabled, #restart-button:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }
        #feedback {
            font-size: 24px;
            margin-top: 10px;
            font-weight: bold;
            min-height: 30px;
            color: #ffffff; /* フィードバックを白に */
        }
        #game-over-screen {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-size: 30px;
            z-index: 1000;
            display: none;
        }
        #final-score {
            margin-top: 20px;
            font-size: 40px;
        }
    </style>
</head>
<body>

    <h1>漢字タップシューティング</h1>

    <div id="game-info">
        <span>スコア: <span id="score">0</span></span>
        <span>残り時間: <span id="time-left">30</span>秒</span>
    </div>

    <div id="hiragana-display"></div>

    <canvas id="gameCanvas" width="600" height="400"></canvas>

    <div id="feedback"></div>

    <button id="start-button">Start</button>

    <div id="game-over-screen">
        <h2>Time Up!</h2>
        <p>Score: <span id="final-score">0</span></p>
        <button id="restart-button">Resume</button>
    </div>

    <script>
        const canvas = document.getElementById('gameCanvas');
        const ctx = canvas.getContext('2d');
        const scoreDisplay = document.getElementById('score');
        const timeLeftDisplay = document.getElementById('time-left');
        const hiraganaDisplay = document.getElementById('hiragana-display');
        const startButton = document.getElementById('start-button');
        const restartButton = document.getElementById('restart-button');
        const feedback = document.getElementById('feedback');
        const gameOverScreen = document.getElementById('game-over-screen');
        const finalScoreDisplay = document.getElementById('final-score');

        let score = 0;
        let timeLeft = 30;
        let fallingKanjis = [];
        let currentTarget = null;
        let gameInterval;
        let kanjiSpawnInterval;
        let timerInterval;
        let gameOver = false;

        // Reduced from 33 to 16 words (approximately half)
        const easyKanji = [
            { kanji: "一人", hiragana: "ひとり" }, { kanji: "二人", hiragana: "ふたり" }, { kanji: "三日", hiragana: "みっか" },
            { kanji: "四角", hiragana: "しかく" }, { kanji: "五つ", hiragana: "いつつ" }, { kanji: "六人", hiragana: "ろくにん" },
            { kanji: "七つ", hiragana: "ななつ" }, { kanji: "八百屋", hiragana: "やおや" }, { kanji: "九月", hiragana: "くがつ" },
            { kanji: "十分", hiragana: "じゅうぶん" }, { kanji: "上手", hiragana: "じょうず" }, { kanji: "下着", hiragana: "したぎ" },
            { kanji: "入口", hiragana: "いりぐち" }, { kanji: "出口", hiragana: "でぐち" }, { kanji: "火山", hiragana: "かざん" },
            { kanji: "水田", hiragana: "すいでん" }
        ];
        // 15 + 20 = 35 words
        const mediumKanji = [
            { kanji: "勉強", hiragana: "べんきょう" }, { kanji: "病院", hiragana: "びょういん" }, { kanji: "図書館", hiragana: "としょかん" },
            { kanji: "運転", hiragana: "うんてん" }, { kanji: "料理", hiragana: "りょうり" }, { kanji: "写真", hiragana: "しゃしん" },
            { kanji: "新聞", hiragana: "しんぶん" }, { kanji: "家族", hiragana: "かぞく" }, { kanji: "季節", hiragana: "きせつ" },
            { kanji: "旅行", hiragana: "りょこう" }, { kanji: "空港", hiragana: "くうこう" }, { kanji: "地球", hiragana: "ちきゅう" },
            { kanji: "動物", hiragana: "どうぶつ" }, { kanji: "植物", hiragana: "しょくぶつ" },
            // Added 20 medium words
            { kanji: "自転車", hiragana: "じてんしゃ" }, { kanji: "教科書", hiragana: "きょうかしょ" }, { kanji: "自動車", hiragana: "じどうしゃ" },
            { kanji: "展覧会", hiragana: "てんらんかい" }, { kanji: "運動会", hiragana: "うんどうかい" }, { kanji: "音楽", hiragana: "おんがく" },
            { kanji: "映画館", hiragana: "えいがかん" }, { kanji: "新幹線", hiragana: "しんかんせん" }, { kanji: "世界", hiragana: "せかい" },
            { kanji: "準備", hiragana: "じゅんび" }, { kanji: "練習", hiragana: "れんしゅう" }, { kanji: "連絡", hiragana: "れんらく" },
            { kanji: "相談", hiragana: "そうだん" }, { kanji: "計画", hiragana: "けいかく" }, { kanji: "経験", hiragana: "けいけん" },
            { kanji: "案内", hiragana: "あんない" }, { kanji: "説明", hiragana: "せつめい" }, { kanji: "紹介", hiragana: "しょうかい" },
            { kanji: "意味", hiragana: "いみ" }, { kanji: "注意", hiragana: "ちゅうい" }, { kanji: "安全", hiragana: "あんぜん" }
        ];
        // 25 + 15 + 20 + 20 = 80 words
        const hardKanji = [
            { kanji: "躊躇", hiragana: "ちゅうちょ" }, { kanji: "斡旋", hiragana: "あっせん" }, { kanji: "漸次", hiragana: "ぜんじ" },
            { kanji: "喧騒", hiragana: "けんそう" }, { kanji: "情緒", hiragana: "じょうしょ" }, { kanji: "憂鬱", hiragana: "ゆううつ" },
            { kanji: "憤慨", hiragana: "ふんがい" }, { kanji: "齟齬", hiragana: "そご" }, { kanji: "頻繁", hiragana: "ひんぱん" },
            { kanji: "網羅", hiragana: "もうら" }, { kanji: "些細", hiragana: "ささい" }, { kanji: "破綻", hiragana: "はたん" },
            { kanji: "寛容", hiragana: "かんよう" }, { kanji: "自律", hiragana: "じりつ" }, { kanji: "邂逅", hiragana: "かいこう" },
            { kanji: "示唆", hiragana: "しさ" }, { kanji: "杜撰", hiragana: "ずさん" }, { kanji: "脆弱", hiragana: "ぜいじゃく" },
            { kanji: "懸念", hiragana: "けねん" }, { kanji: "煩瑣", hiragana: "はんさ" }, { kanji: "汎用", hiragana: "はんよう" },
            { kanji: "克己", hiragana: "こっき" }, { kanji: "恩赦", hiragana: "おんしゃ" }, { kanji: "僥倖", hiragana: "ぎょうこう" },
            { kanji: "忖度", hiragana: "そんたく" },
            // Added 15 hard words previously
            { kanji: "概念", hiragana: "がいねん" }, { kanji: "毅然", hiragana: "きぜん" }, { kanji: "驚愕", hiragana: "きょうがく" },
            { kanji: "厳格", hiragana: "げんかく" }, { kanji: "語彙", hiragana: "ごい" }, { kanji: "混沌", hiragana: "こんとん" },
            { kanji: "錯綜", hiragana: "さくそう" }, { kanji: "斬新", hiragana: "ざんしん" }, { kanji: "執着", hiragana: "しゅうちゃく" },
            { kanji: "真摯", hiragana: "しんし" }, { kanji: "衰退", hiragana: "すいたい" }, { kanji: "前提", hiragana: "ぜんてい" },
            { kanji: "打破", hiragana: "だは" }, { kanji: "破棄", hiragana: "はき" }, { kanji: "変遷", hiragana: "へんせん" },
            // Added 20 more hard words previously
            { kanji: "葛藤", hiragana: "かっとう" }, { kanji: "虚無", hiragana: "きょむ" }, { kanji: "誇張", hiragana: "こちょう" },
            { kanji: "核心", hiragana: "かくしん" }, { kanji: "乖離", hiragana: "かいり" }, { kanji: "形骸", hiragana: "けいがい" },
            { kanji: "啓発", hiragana: "けいはつ" }, { kanji: "掌握", hiragana: "しょうあく" }, { kanji: "洗練", hiragana: "せんれん" },
            { kanji: "脱却", hiragana: "だっきゃく" }, { kanji: "妥協", hiragana: "だきょう" }, { kanji: "抽象", hiragana: "ちゅうしょう" },
            { kanji: "淘汰", hiragana: "とうた" }, { kanji: "批准", hiragana: "ひじゅん" }, { kanji: "偏見", hiragana: "へんけん" },
            { kanji: "模索", hiragana: "もさく" }, { kanji: "躍進", hiragana: "やくしん" }, { kanji: "拉致", hiragana: "らち" },
            { kanji: "利害", hiragana: "りがい" }, { kanji: "凌駕", hiragana: "りょうが" },
            // Added 20 new highly difficult words
            { kanji: "孤高", hiragana: "ここう" }, { kanji: "巧妙", hiragana: "こうみょう" }, { kanji: "卓越", hiragana: "たくえつ" },
            { kanji: "真髄", hiragana: "しんずい" }, { kanji: "羨望", hiragana: "せんぼう" }, { kanji: "超越", hiragana: "ちょうえつ" },
            { kanji: "不条理", hiragana: "ふじょうり" }, { kanji: "変革", hiragana: "へんかく" }, { kanji: "陳腐", hiragana: "ちんぷ" },
            { kanji: "擁護", hiragana: "ようご" }, { kanji: "抑圧", hiragana: "よくあつ" }, { kanji: "凌辱", hiragana: "りょうじょく" },
            { kanji: "威厳", hiragana: "いげん" }, { kanji: "隠蔽", hiragana: "いんぺい" }, { kanji: "解釈", hiragana: "かいしゃく" },
            { kanji: "固執", hiragana: "こしつ" }, { kanji: "終焉", hiragana: "しゅうえん" }, { kanji: "深淵", hiragana: "しんえん" },
            { kanji: "中傷", hiragana: "ちゅうしょう" }, { kanji: "捏造", hiragana: "ねつぞう" }
        ];

        let currentKanjiPool = [];

        const kanjiSize = 30; // Font size for kanji
        const initialKanjiSpeed = 1.0; // Initial falling speed
        const initialSpawnDelay = 1000; // Initial spawn delay (ms)
        const hitboxMultiplier = 2; // Multiplier for hit detection area

        function updateGameInfo() {
            scoreDisplay.textContent = score;
        }

        function updateTimerDisplay() {
            timeLeftDisplay.textContent = timeLeft;
        }

        function getKanjiPool() {
            if (score < 50) {
                return easyKanji;
            } else if (score < 100) {
                return easyKanji.concat(mediumKanji);
            } else {
                return easyKanji.concat(mediumKanji, hardKanji);
            }
        }

        function getKanjiSpeed() {
            return initialKanjiSpeed + (score / 75);
        }

        function getSpawnDelay() {
            return Math.max(500, initialSpawnDelay - (score * 10));
        }

        function spawnKanji() {
            if (gameOver) return null;

            currentKanjiPool = getKanjiPool();
            if (currentKanjiPool.length === 0) return null;

            let newKanjiData;
            let attempts = 0;
            do {
                newKanjiData = currentKanjiPool[Math.floor(Math.random() * currentKanjiPool.length)];
                attempts++;
                if (attempts > 50 && currentKanjiPool.length > 0) {
                     newKanjiData = currentKanjiPool[Math.floor(Math.random() * currentKanjiPool.length)];
                     break;
                }
            } while (fallingKanjis.some(k => k.kanji === newKanjiData.kanji));

            if (!newKanjiData) return null;

            let kanjiX;
            let overlapping = true;
            let spawnAttempts = 0;
            const maxSpawnAttempts = 50;

            while (overlapping && spawnAttempts < maxSpawnAttempts) {
                kanjiX = Math.random() * (canvas.width - kanjiSize * 2) + kanjiSize;
                overlapping = false;
                for (let i = 0; i < fallingKanjis.length; i++) {
                    const existingKanji = fallingKanjis[i];
                    if (existingKanji.y < kanjiSize * 2 && Math.abs(kanjiX - existingKanji.x) < kanjiSize * 1.5) {
                        overlapping = true;
                        break;
                    }
                }
                spawnAttempts++;
            }

            const newKanji = {
                kanji: newKanjiData.kanji,
                hiragana: newKanjiData.hiragana,
                x: kanjiX,
                y: -kanjiSize,
                speed: getKanjiSpeed(),
                id: Date.now() + Math.random()
            };
            fallingKanjis.push(newKanji);

            return newKanji;
        }

        function setNewTarget(kanjiObject) {
            currentTarget = kanjiObject;
            hiraganaDisplay.textContent = currentTarget ? currentTarget.hiragana : '';
            feedback.textContent = '';
        }

        function drawKanjis() {
            ctx.font = `bold ${kanjiSize}px 'Arial', 'Meiryo', sans-serif`;
            ctx.textAlign = 'center';

            fallingKanjis.forEach((k, index) => {
                ctx.fillStyle = 'white';
                ctx.fillText(k.kanji, k.x, k.y);

                k.y += k.speed;

                if (k.y > canvas.height + kanjiSize) {
                    const wasTarget = (currentTarget && k.id === currentTarget.id);
                    fallingKanjis.splice(index, 1);

                    if (wasTarget) {
                        feedback.textContent = `残念！${k.kanji}が落ちてしまいました。`;
                        feedback.style.color = 'orange';

                        const newTarget = spawnKanji();
                        if (newTarget) {
                            setNewTarget(newTarget);
                            spawnKanji();
                            spawnKanji();
                        } else {
                            setNewTarget(fallingKanjis.length > 0 ? fallingKanjis[0] : null);
                        }
                    }
                }
            });
        }

        function handleCanvasClick(event) {
            if (gameOver || !currentTarget) return;

            const rect = canvas.getBoundingClientRect();
            const clickX = event.clientX - rect.left;
            const clickY = event.clientY - rect.top;

            let hitKanji = null;
            let hitIndex = -1;

            for (let i = 0; i < fallingKanjis.length; i++) {
                const k = fallingKanjis[i];
                const effectiveKanjiSize = kanjiSize * hitboxMultiplier;
                const kanjiLeft = k.x - effectiveKanjiSize / 2;
                const kanjiRight = k.x + effectiveKanjiSize / 2;
                const kanjiTop = k.y - effectiveKanjiSize;
                const kanjiBottom = k.y;

                if (clickX >= kanjiLeft && clickX <= kanjiRight &&
                    clickY >= kanjiTop && clickY <= kanjiBottom) {
                    hitKanji = k;
                    hitIndex = i;
                    break;
                }
            }

            if (hitKanji) {
                if (hitKanji.id === currentTarget.id) {
                    feedback.textContent = `⭕ 正解！ 「${currentTarget.kanji}」`;
                    feedback.style.color = 'green';
                    score += 10;

                    fallingKanjis.splice(hitIndex, 1);

                    const newTarget = spawnKanji();
                    if (newTarget) {
                        setNewTarget(newTarget);
                        spawnKanji();
                        spawnKanji();
                    } else {
                        setNewTarget(null);
                    }

                } else {
                    feedback.textContent = `❌ 不正解！違う漢字です。（${hitKanji.kanji}）`;
                    feedback.style.color = 'red';
                    score = Math.max(0, score - 5);
                }
            } else {
                feedback.textContent = `❌ 空振り！`;
                feedback.style.color = 'gray';
            }

            updateGameInfo();
        }

        function gameLoop() {
            if (gameOver) return;

            ctx.clearRect(0, 0, canvas.width, canvas.height);
            drawKanjis();

            const currentSpawnDelay = getSpawnDelay();
            if (kanjiSpawnInterval._delay !== currentSpawnDelay) {
                clearInterval(kanjiSpawnInterval);
                kanjiSpawnInterval = setInterval(spawnKanji, currentSpawnDelay);
                kanjiSpawnInterval._delay = currentSpawnDelay;
            }
        }

        function startGame() {
            score = 0;
            timeLeft = 30;
            fallingKanjis = [];
            currentTarget = null;
            gameOver = false;
            gameOverScreen.style.display = 'none';
            startButton.style.display = 'none';
            feedback.textContent = '';
            updateGameInfo();
            updateTimerDisplay();

            currentKanjiPool = easyKanji;

            const initialTargetKanji = spawnKanji();
            if (initialTargetKanji) {
                setNewTarget(initialTargetKanji);
                spawnKanji();
                spawnKanji();
            } else {
                setNewTarget(null);
            }

            gameInterval = setInterval(gameLoop, 1000 / 60);
            kanjiSpawnInterval = setInterval(spawnKanji, initialSpawnDelay);
            kanjiSpawnInterval._delay = initialSpawnDelay;

            timerInterval = setInterval(() => {
                timeLeft--;
                updateTimerDisplay();
                if (timeLeft <= 0) {
                    endGame();
                }
            }, 1000);
        }

        function endGame() {
            gameOver = true;
            clearInterval(gameInterval);
            clearInterval(kanjiSpawnInterval);
            clearInterval(timerInterval);
            finalScoreDisplay.textContent = score;
            gameOverScreen.style.display = 'flex';
            startButton.style.display = 'inline-block';
            hiraganaDisplay.textContent = '';
        }

        // Event Listeners
        startButton.addEventListener('click', startGame);
        restartButton.addEventListener('click', startGame);
        canvas.addEventListener('click', handleCanvasClick);

        // Initial setup
        updateGameInfo();
        updateTimerDisplay();
        hiraganaDisplay.textContent = '';

    </script>

</body>
</html>"""


# iframe内でゲームを動かし、元のJavaScriptゲームをGradio画面に表示します。
iframe_srcdoc = html.escape(html_content, quote=True)

with gr.Blocks(title="漢字タップシューティング") as demo:
    gr.Markdown("# 漢字タップシューティング")
    gr.Markdown("画面内の漢字をタップして、お題の読みと一致する漢字を狙おう！")
    gr.HTML(
        f"""<iframe
            title="漢字タップシューティングゲーム"
            srcdoc="{iframe_srcdoc}"
            sandbox="allow-scripts"
            style="display:block; width:100%; height:780px; border:0; background:#000;"
        ></iframe>"""
    )

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "10000"))
    demo.launch(server_name="0.0.0.0", server_port=port, share=False)
